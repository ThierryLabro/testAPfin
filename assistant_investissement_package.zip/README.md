# Assistant d'Investissement Streamlit

Cette application vous aide à choisir des produits financiers selon votre profil.