
import streamlit as st
import pandas as pd

st.title("Assistant d'Investissement - Produits Financiers Grand Public")

st.markdown("Bienvenue ! Cet assistant vous aide à choisir des produits financiers adaptés à votre profil et vos objectifs.")

profil = st.selectbox("Quel est votre profil d'investisseur ?", ["Prudent", "Équilibré", "Dynamique"])
montant = st.number_input("Quel montant souhaitez-vous investir ?", min_value=1000, max_value=1000000, value=10000, step=500)

data = {
    "Produit": [
        "Compte rémunéré", "Livret réglementé", "Compte à terme", "Obligations d'État",
        "Obligations d'entreprise", "Fonds obligataires", "Actions individuelles", "ETF (trackers)",
        "Fonds communs de placement (OPCVM)", "Assurance-vie", "Plan d’épargne retraite (PER)", "SCPI / OPCI"
    ],
    "Rendement (%)": [2, 2.5, 3.5, 3, 4.5, 3, 7, 6, 5, 4, 4.5, 5],
    "Risque (1-5)": [1, 1, 1, 2, 3, 2, 4, 3, 3, 2, 3, 2],
    "Liquidité (1-5)": [5, 5, 2, 4, 3, 3, 5, 5, 3, 3, 1, 2],
    "Profil Prudent": [1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0],
    "Profil Équilibré": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    "Profil Dynamique": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
}

df = pd.DataFrame(data)
profil_col = f"Profil {profil}"
df_filtered = df[df[profil_col] == 1]

st.subheader("Produits recommandés selon votre profil :")
st.dataframe(df_filtered[["Produit", "Rendement (%)", "Risque (1-5)", "Liquidité (1-5)"]])

st.subheader("Suggestion de répartition (exemple équilibré)")
parts = len(df_filtered)
allocation = montant / parts if parts > 0 else 0
df_filtered["Montant conseillé (€)"] = round(allocation, 2)
st.dataframe(df_filtered[["Produit", "Montant conseillé (€)"]])
